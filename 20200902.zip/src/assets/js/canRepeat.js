// 可以重复发送的请求
export const repeatRequestList = ['',''];
// 不需要loading的请求
export const notLoadingList = [];

// 存放每一个请求的取消函数
export const cancleRequestList = [];
